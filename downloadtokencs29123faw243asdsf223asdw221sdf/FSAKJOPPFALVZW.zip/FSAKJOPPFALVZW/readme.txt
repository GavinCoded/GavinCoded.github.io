kill the faggots
I fucking hate faggots the esp took way too long to make for it being that simple
